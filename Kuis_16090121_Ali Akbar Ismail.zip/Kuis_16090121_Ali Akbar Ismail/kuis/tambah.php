<?php
 
 /*
 
 penulis: Muhammad yusuf
 website: https://www.kodingindonesia.com/
 
 */
 
	if($_SERVER['REQUEST_METHOD']=='POST'){
		
		//Mendapatkan Nilai Variable
		$kode = $_POST['kode'];
		$nama = $_POST['nama'];
		$kategori = $_POST['kategori'];
		$warna = $_POST['warna'];
		
		//Pembuatan Syntax SQL
		$sql = "INSERT INTO data_hewan (kode,nama,kategori,warna) VALUES ('$kode','$nama','$kategori', '$warna')";
		
		//Import File Koneksi database
		require_once('koneksi.php');
		
		//Eksekusi Query database
		if(mysqli_query($con,$sql)){
		echo 'Berhasil Menambahkan data';
		}else{
		echo 'Gagal Menambahkan data';
		}
		
		mysqli_close($con);
	}
?>