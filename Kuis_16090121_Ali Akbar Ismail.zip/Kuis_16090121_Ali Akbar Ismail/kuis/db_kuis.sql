-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 03, 2019 at 05:19 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_kuis`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_hewan`
--

CREATE TABLE `data_hewan` (
  `kode` int(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `kategori` varchar(100) NOT NULL,
  `warna` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_hewan`
--

INSERT INTO `data_hewan` (`kode`, `nama`, `kategori`, `warna`) VALUES
(1, 'kucying', 'buas', 'ijo'),
(2, 'fjj', 'gjk', 'vjk'),
(3, 'fhj', 'cbk', 'xhj'),
(4, 'fhj', 'cbk', 'xhj'),
(5, 'fhj', 'cbk', 'xhj'),
(6, 'dgh', 'cbb', 'cnn'),
(7, 'dgh', 'cbb', 'cnn'),
(8, 'dgh', 'cbb', 'cnn'),
(9, 'dgh', 'cbb', 'cnn'),
(10, 'dgh', 'cbb', 'cnn'),
(11, 'ggg', 'ggh', 'vbb'),
(12, 'ggg', 'ggh', 'vbb'),
(13, 'ggg', 'ggh', 'vbb'),
(14, 'ggg', 'ggh', 'vbb'),
(15, 'ggg', 'ggh', 'vbb'),
(16, 'ggg', 'ggh', 'vbb'),
(17, 'ggg', 'ggh', 'vbb'),
(18, 'ggg', 'ggh', 'vbb'),
(19, 'ggg', 'ggh', 'vbb'),
(20, 'fvgv', 'dhh', 'cbn'),
(21, 'fvgv', 'dhh', 'cbn'),
(22, 'dvh', 'cbn', 'xgj'),
(23, 'fgu', 'dgj', 'fgi'),
(24, 'fgu', 'dgj', 'fgi'),
(25, 'fgu', 'dgj', 'fgi'),
(26, 'xgh', 'fhh', 'fhh'),
(27, 'xgh', 'fhh', 'fhh'),
(28, 'xgh', 'fhh', 'fhh'),
(29, 'xgh', 'fhh', 'fhh'),
(30, 'xgh', 'fhh', 'fhh'),
(31, 'xgh', 'fhh', 'fhh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_hewan`
--
ALTER TABLE `data_hewan`
  ADD PRIMARY KEY (`kode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_hewan`
--
ALTER TABLE `data_hewan`
  MODIFY `kode` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
